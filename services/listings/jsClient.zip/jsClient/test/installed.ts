import { config } from 'dotenv';
config();
import { AUCTIONClient, utils, constants } from '../src';
import { parseTokenMeta, sleep, getDeploy } from './utils';
// import { Axios } from 'axios';
const axios = require('axios').default;

import {
  CLValueBuilder,
  Keys,
  CLPublicKey,
  CLAccountHash,
  CLPublicKeyType,
} from 'casper-js-sdk';

const { AUCTIONEvents } = constants;

const {
  NODE_ADDRESS,
  EVENT_STREAM_ADDRESS,
  CHAIN_NAME,

  MASTER_KEY_PAIR_PATH,
  CONTRACT_NAME,
  RESERVE_WISE_PAYMENT_AMOUNT,

  CREATED_AT,
  SLUG,
  ID,
  CURRENT_PRICE,
  STATUS,
  EXPIRES_AT,
  START_PRICE,
  CURRENT_WINNER_ID,
  INVENTORY_ITEM_ID,
  PAYMENT_CONFIRMATION,
  MASS_OF_ITEM,
  TAX_BY_MASS_OF_ITEM,
  SALES_TAX,
  EXCISE_RATE,
  TOTAL_PRICE,
  USER_ID,
  TITLE,
  DESCRIPTION,
  IMAGE_ID,
  SMALL_IMAGE,
  LARGE_IMAGE,
  VERSION,
  SIMPLE_AUCTION_CONTRACT_HASH,
} = process.env;

const KEYS = Keys.Ed25519.parseKeyFiles(
  `${MASTER_KEY_PAIR_PATH}/public_key.pem`,
  `${MASTER_KEY_PAIR_PATH}/secret_key.pem`
);

const auction = new AUCTIONClient(
  NODE_ADDRESS!,
  CHAIN_NAME!,
  EVENT_STREAM_ADDRESS!
);

export const store = async (
  created_at: string,
  slug: string,
  id: string,
  current_price: string,
  _status: string,
  expires_at: string,
  start_price: string,
  current_winner_id: string,
  inventory_item_id: string,
  payment_confirmation: string,
  mass_of_item: string,
  tax_by_mass_of_item: string,
  sales_tax: string,
  excise_rate: string,
  total_price: string,
  user_id: string,
  fixPrice: number,
  quantity: number,
  title: string,
  description: string,
  image_id: string,
  small_image: string,
  large_image: string,
  version: string
) => {
  const store_deploy = await auction.store(
    KEYS,
    created_at,
    slug,
    id,
    current_price,
    _status,
    expires_at,
    start_price,
    current_winner_id,
    inventory_item_id,
    payment_confirmation,
    mass_of_item,
    tax_by_mass_of_item,
    sales_tax,
    excise_rate,
    total_price,
    user_id,
    title,
    description,
    image_id,
    small_image,
    large_image,
    version,
    RESERVE_WISE_PAYMENT_AMOUNT!
  );
  console.log('... store deploy hash: ', store_deploy);
  const result = await getDeploy(NODE_ADDRESS!, store_deploy);
  var resultData = JSON.parse(JSON.stringify(result));
  console.log('Result data : ', resultData);
  console.log('Result : ' + Object.prototype.toString.call(result));

  let axiosStatus;

  if (resultData !== 'Mint error: 0' && resultData !== 0) {
    console.log('... store created successfully');

    await axios({
      method: 'post',
      url: 'http://auctionweb.site:8080/api/listings',
      data: {
        start_price,
        title,
        description,
        expires_at,
        payment_confirmation,
        mass_of_item,
        quantity,
        fixPrice,
      },
    })
      .then(function (response: any) {
        console.log('Data : ' + JSON.stringify(response.data));
        console.log('Status : ' + response.status);
        console.log('Status Text : ' + response.statusText);
        console.log('Header : ' + response.headers);
        // console.log(response.config);
        axiosStatus = true;
      })
      .catch(function (error: any) {
        console.log(error);
        axiosStatus = false;
      });
  }
  return axiosStatus;
};

export const update = async (
  created_at: string,
  slug: string,
  id: string,
  current_price: string,
  _status: string,
  expires_at: string,
  start_price: string,
  current_winner_id: string,
  inventory_item_id: string,
  payment_confirmation: string,
  mass_of_item: string,
  tax_by_mass_of_item: string,
  sales_tax: string,
  excise_rate: string,
  total_price: string,
  user_id: string,
  title: string,
  description: string,
  image_id: string,
  small_image: string,
  large_image: string,
  version: string
) => {
  const update_deploy = await auction.update(
    KEYS,
    created_at,
    slug,
    id,
    current_price,
    _status,
    expires_at,
    start_price,
    current_winner_id,
    inventory_item_id,
    payment_confirmation,
    mass_of_item,
    tax_by_mass_of_item,
    sales_tax,
    excise_rate,
    total_price,
    user_id,
    title,
    description,
    image_id,
    small_image,
    large_image,
    version,
    RESERVE_WISE_PAYMENT_AMOUNT!
  );
  console.log('... update deploy test hash: ', update_deploy);
  await getDeploy(NODE_ADDRESS!, update_deploy);
  console.log('... update created test successfully');
};

export const get_data = async (id: string) => {
  const get_data_deploy = await auction.get_data(ID!);
  console.log(`... Contract get_data: ${get_data_deploy}`);
};

const test = async () => {
  await auction.setContractHash(SIMPLE_AUCTION_CONTRACT_HASH!);

  console.log('... Contract Hash:', SIMPLE_AUCTION_CONTRACT_HASH!);

  const store_deploy_test = await auction.store(
    KEYS,
    CREATED_AT!,
    SLUG!,
    ID!,
    CURRENT_PRICE!,
    STATUS!,
    EXPIRES_AT!,
    START_PRICE!,
    CURRENT_WINNER_ID!,
    INVENTORY_ITEM_ID!,
    PAYMENT_CONFIRMATION!,
    MASS_OF_ITEM!,
    TAX_BY_MASS_OF_ITEM!,
    SALES_TAX!,
    EXCISE_RATE!,
    TOTAL_PRICE!,
    USER_ID!,
    TITLE!,
    DESCRIPTION!,
    IMAGE_ID!,
    SMALL_IMAGE!,
    LARGE_IMAGE!,
    VERSION!,
    RESERVE_WISE_PAYMENT_AMOUNT!
  );
  console.log('... store deploy test hash: ', store_deploy_test);

  await getDeploy(NODE_ADDRESS!, store_deploy_test);
  console.log('... store created test successfully');

  const update_deploy_test = await auction.update(
    KEYS,
    CREATED_AT!,
    SLUG!,
    ID!,
    CURRENT_PRICE!,
    STATUS!,
    EXPIRES_AT!,
    START_PRICE!,
    CURRENT_WINNER_ID!,
    INVENTORY_ITEM_ID!,
    PAYMENT_CONFIRMATION!,
    MASS_OF_ITEM!,
    TAX_BY_MASS_OF_ITEM!,
    SALES_TAX!,
    EXCISE_RATE!,
    TOTAL_PRICE!,
    USER_ID!,
    TITLE!,
    DESCRIPTION!,
    IMAGE_ID!,
    SMALL_IMAGE!,
    LARGE_IMAGE!,
    VERSION!,
    RESERVE_WISE_PAYMENT_AMOUNT!
  );
  console.log('... update deploy test hash: ', update_deploy_test);
  await getDeploy(NODE_ADDRESS!, update_deploy_test);
  console.log('... update created test successfully');
  // /*=========================Getters=========================*/

  // const get_data_test = await auction.get_data(ID!);
  // console.log(`... Contract get_data_test: ${get_data}`);
};

test();
