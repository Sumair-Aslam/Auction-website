export enum AUCTIONEvents {
	Store = "auction_data_stored",
	Update = "auction_data_updated",
	Get_data = "auction_data_retrieved",
}
